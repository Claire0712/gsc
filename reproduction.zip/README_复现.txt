HeatSignal 统一复现包 v6

当前论文：deliverables/2026-11-01_HeatSignal_manuscript_v32_draft.pdf及.docx（44页）；补表：deliverables/2026-11-01_supplement_tables_v4/supplement_tables.pdf及.docx（19页）；当前网页：deliverables/2026-11-01_platform_v4c/index.html。旧版本保留为来源/回归对照，以上路径是当前版本。

默认下游复现：python scripts/reproduce_delivery.py --rebuild --receipt /已有目录/新的receipt.json。无--rebuild仅核验清单。新临时根重导出四主表、原补表、全部M3交互/原全窗峰值，重组合19页补表和44页Word；数值文件逐字节对照，Word段落/单元格/图片/section对照。默认依赖Python3.11/3.12、numpy、pandas、python-docx；不安装软件、不下载、不启动服务、不重编译PDF或重算原始全球气象/IODA。

当前网站可在本地手动打开；解压deliverables/2026-11-01_platform_v4c_rebuild_bundle.zip到另一个空目录，按其REBUILD_INSTRUCTIONS.txt重建并运行9项Node测试（Node22已测）。HTML独立重建逐字节相等；未作真实浏览器/用户可用性认证，没有已验证公共网址。

M3科学复现另需scipy、statsmodels（Judy judy环境已测，版本见outputs/2026-11-01_M3_isolated_server_reproduction.json）：
python -m scripts.run_proposal_interactions_20261101 --panel analysis/2026-10-13_event_panel/v1/full_outputs --original analysis/2026-10-13_heat_associations/v2/full_outputs --output NEW_EMPTY_M3_OUTPUT
python -m scripts.audit_proposal_interactions_20261101 --panel analysis/2026-10-13_event_panel/v1/full_outputs --original analysis/2026-10-13_heat_associations/v2/full_outputs --output NEW_EMPTY_M3_OUTPUT
原事件面板、A/M2矩阵和两份原status.json均已附；新输出路径必须不存在。Judy独立解压v5后发现缺少两份状态元数据，显式补入原文件后全部M3结果逐字节复现，独立审计通过；本v6包含该补丁所需原文件，源哈希已核对，不把未补的v5说成科学复现成功。

原始大型输入仍在/volume1/homes/Judy/GSC2027/HeatSignal，主ERA5/volume1/homes/Judy/GSC2027/era5。完整项目源码/测试保留不表示所有旧脚本无需NAS原始输入即可运行；不得恢复下载或覆盖旧结果。可选重绘需matplotlib/geopandas/pyproj/Arial，原Nature helper逐字节附vendor/，可用PYTHONPATH=vendor补足旧脚本个人目录依赖。

M3是已看主结果后的原proposal漏项补做，单独30检验家族，不是外部预注册或全研究FDR。所有缺失、不可估、相反/不显著及AP新交互结果保留。科学解释限制见随包proposal对照与论文，最终分发验收另附在顶层交付目录，不将流程通过当作因果结论。
